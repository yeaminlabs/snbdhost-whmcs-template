{* Empty sidebar template *}
